import { UserEntity } from '../modules/user/user.entity';
import { ProductEntity } from '../modules/product/product.entity';
const AllModels = [UserEntity, ProductEntity];
export { UserEntity, ProductEntity, AllModels };
